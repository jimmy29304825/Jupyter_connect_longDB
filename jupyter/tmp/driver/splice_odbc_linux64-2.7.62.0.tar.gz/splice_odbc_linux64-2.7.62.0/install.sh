#!/bin/bash

# 64-bit install file

# XXX - RHEL/Debian diffs (lib paths, etc.)

if [ -x /usr/bin/clear ]; then
    /usr/bin/clear
fi
cat <<EOF

Installing Splice Machine 64-bit ODBC Driver...

EOF

if [ "$(id -u)" == "0" ]; then
    defpath="/usr/local"
else
    defpath="$HOME"
fi

echo -n "Install to directory [$defpath]: "
read path

if [ "$path" == "" ]; then
    path="$defpath"
fi

fullpath=`echo $path/splice | sed 's,//,/,g'`

# multiarch on Debian uses "lib" for arch-specific libs regardless of 
LIBDIR="lib"

# RHEL-based OS uses /usr/lib for 32-bit and /usr/lib64 for 64-bit
# figure this out from rpm
test -e /etc/redhat-release && {
	LIBDIR="$(rpm --eval '%{_libdir}' | xargs basename)"
}

if [ ! -d "$fullpath" ];then
    mkdir -p $fullpath/${LIBDIR}
    mkdir -p $fullpath/errormessages/en-US
fi

echo -n "Please enter the IP address for the Splice Machine server [127.0.0.1]? "
read ipaddr
if [ "$ipaddr" == "" ]; then
    ipaddr="127.0.0.1"
fi

cat odbc.template | sed "s#_INSTALLDIR_#$fullpath/$LIBDIR#;s#_IPADDR_#$ipaddr#" > odbc.ini
cat odbcinst.template | sed "s#_INSTALLDIR_#$fullpath/$LIBDIR#" > odbcinst.ini
cat splice.odbcdriver.template | sed "s#_INSTALLDIR_#$fullpath#" > splice.odbcdriver.ini
if [ "$(id -u)" == "0" ]; then
    chmod 666 odbc*.ini
    chmod 666 splice.odbcdriver.ini
fi

# move required files to a common location
cp -av errormessages/en-US/*.xml $fullpath/errormessages/en-US
cp -av lib64/*.so $fullpath/${LIBDIR}
cp -av README $fullpath/README
cp -av VERSION $fullpath/VERSION

if [ "$(id -u)" == "0" ]; then
    # move config files into system area
    if [ -f "/etc/odbc.ini" ]; then
        mv /etc/odbc.ini /etc/odbc.ini.1
    fi
    cp -av odbc.ini /etc/odbc.ini

    if [ -f "/etc/odbcinst.ini" ]; then
        mv /etc/odbcinst.ini /etc/odbcinst.ini.1
    fi
    cp -av odbcinst.ini /etc/odbcinst.ini

    if [ -f "/etc/splice.odbcdriver.ini" ]; then
        mv /etc/splice.odbcdriver.ini /etc/splice.odbcdriver.ini.1
    fi
    cp -av splice.odbcdriver.ini /etc/splice.odbcdriver.ini
else
    # move config files into user area
    if [ -f "$HOME/.odbc.ini" ]; then
        mv $HOME/.odbc.ini $HOME/.odbc.ini.1
    fi
    cp -av odbc.ini $HOME/.odbc.ini

    if [ -f "$HOME/.odbcinst.ini" ]; then
        mv $HOME/.odbcinst.ini $HOME/.odbcinst.ini.1
    fi
    cp -av odbcinst.ini $HOME/.odbcinst.ini

    if [ -f "$HOME/.splice.odbcdriver.ini" ]; then
        mv $HOME/.splice.odbcdriver.ini $HOME/.splice.odbcdriver.ini.1
    fi
    cp -av splice.odbcdriver.ini $HOME/.splice.odbcdriver.ini
fi

echo -n "Installation complete... [enter] "
read foo

if [ -x /usr/bin/clear ]; then
    /usr/bin/clear
fi

cat README

